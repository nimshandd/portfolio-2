import Navbar from "./components/Navbar";

function App() {
  return (
    <div className="bg-[#0B0B0B] min-h-screen text-white">
      <Navbar />
    </div>
  );
}

export default App;