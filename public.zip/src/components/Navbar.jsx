import profile from "../data/profile";

function Navbar() {
  return (
    <nav className="sticky top-0 z-50 bg-[#0B0B0B]/90 backdrop-blur border-b border-zinc-800">
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        
        <h1 className="text-xl font-bold text-white">
          {profile.name.split(" ")[2]}
        </h1>

        <ul className="hidden md:flex items-center gap-8 text-sm text-zinc-300">
          <li>
            <a href="#about" className="hover:text-purple-500 transition">
              About
            </a>
          </li>

          <li>
            <a href="#projects" className="hover:text-purple-500 transition">
              Projects
            </a>
          </li>

          <li>
            <a href="#skills" className="hover:text-purple-500 transition">
              Skills
            </a>
          </li>

          <li>
            <a href="#contact" className="hover:text-purple-500 transition">
              Contact
            </a>
          </li>
        </ul>
      </div>
    </nav>
  );
}

export default Navbar;